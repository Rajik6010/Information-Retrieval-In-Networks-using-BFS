Run the code labelled bfs.c in any C compiler.

Observe the output of the run file and record.